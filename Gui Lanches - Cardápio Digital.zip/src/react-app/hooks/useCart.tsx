import { createContext, useContext, useState, ReactNode } from 'react';
import { CartItem, MenuItem } from '@/shared/types';

interface CartContextType {
  items: CartItem[];
  addItem: (item: MenuItem, size?: 'small' | 'large' | 'regular') => void;
  removeItem: (itemId: string, size?: 'small' | 'large' | 'regular') => void;
  updateQuantity: (itemId: string, quantity: number, size?: 'small' | 'large' | 'regular') => void;
  clearCart: () => void;
  getTotalPrice: () => number;
  getTotalItems: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const addItem = (item: MenuItem, size: 'small' | 'large' | 'regular' = 'regular') => {
    setItems(prevItems => {
      const existingItem = prevItems.find(
        cartItem => cartItem.item.id === item.id && cartItem.size === size
      );

      if (existingItem) {
        return prevItems.map(cartItem =>
          cartItem.item.id === item.id && cartItem.size === size
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }

      return [...prevItems, { item, quantity: 1, size }];
    });
  };

  const removeItem = (itemId: string, size: 'small' | 'large' | 'regular' = 'regular') => {
    setItems(prevItems => 
      prevItems.filter(item => !(item.item.id === itemId && item.size === size))
    );
  };

  const updateQuantity = (itemId: string, quantity: number, size: 'small' | 'large' | 'regular' = 'regular') => {
    if (quantity <= 0) {
      removeItem(itemId, size);
      return;
    }

    setItems(prevItems =>
      prevItems.map(item =>
        item.item.id === itemId && item.size === size
          ? { ...item, quantity }
          : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const getTotalPrice = () => {
    return items.reduce((total, cartItem) => {
      const price = getItemPrice(cartItem.item, cartItem.size);
      return total + (price * cartItem.quantity);
    }, 0);
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  const getItemPrice = (item: MenuItem, size?: 'small' | 'large' | 'regular') => {
    if (item.priceSmall && item.priceLarge) {
      return size === 'large' ? item.priceLarge : item.priceSmall;
    }
    return item.price || 0;
  };

  return (
    <CartContext.Provider value={{
      items,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      getTotalPrice,
      getTotalItems,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
