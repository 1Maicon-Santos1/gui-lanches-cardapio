import { MenuItem, Category } from '@/shared/types';

export const categories: Category[] = [
  { id: 'tradicional', name: 'Tradicional Artesanal', emoji: '🧡', color: 'bg-orange-100 text-orange-800 border-orange-200' },
  { id: 'frango', name: 'Lanches com Frango', emoji: '🐔', color: 'bg-yellow-100 text-yellow-800 border-yellow-200' },
  { id: 'gourmet', name: 'Lanches Gourmet', emoji: '🔥', color: 'bg-red-100 text-red-800 border-red-200' },
  { id: 'saborosos', name: 'Lanches Saborosos', emoji: '🧀', color: 'bg-blue-100 text-blue-800 border-blue-200' },
  { id: 'combos', name: 'Combos e Especiais', emoji: '🧋', color: 'bg-purple-100 text-purple-800 border-purple-200' },
  { id: 'beirutes', name: 'Beirutes e Bauru', emoji: '🥪', color: 'bg-green-100 text-green-800 border-green-200' },
  { id: 'acompanhamentos', name: 'Acompanhamentos', emoji: '🍟', color: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
];

export const menuItems: MenuItem[] = [
  // Tradicional Artesanal
  {
    id: 'triplo-x',
    name: 'Triplo X',
    description: 'Hambúrguer, presunto, queijo, bacon, ovo, maionese, tomate e alface',
    priceSmall: 36,
    priceLarge: 44,
    category: 'tradicional',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400',
    ingredients: ['hambúrguer', 'presunto', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-quarteirao',
    name: 'X-Quarteirão',
    description: 'Hambúrguer, presunto, queijo, bacon, ovo, maionese, tomate e alface',
    priceSmall: 33,
    priceLarge: 39,
    category: 'tradicional',
    preparationTime: '10-12 min',
    image: 'https://images.unsplash.com/photo-1551782450-17144efb9c50?w=400',
    ingredients: ['hambúrguer', 'presunto', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-tudo',
    name: 'X-Tudo',
    description: 'Hambúrguer, presunto, queijo, bacon, calabresa, ovo, maionese, tomate e alface',
    priceSmall: 33,
    priceLarge: 39,
    category: 'tradicional',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400',
    ingredients: ['hambúrguer', 'presunto', 'queijo', 'bacon', 'calabresa', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-calabresa',
    name: 'X-Calabresa',
    description: 'Hambúrguer, calabresa, queijo, maionese, tomate e alface',
    priceSmall: 27,
    priceLarge: 30,
    category: 'tradicional',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400',
    ingredients: ['hambúrguer', 'calabresa', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-salada',
    name: 'X-Salada',
    description: 'Hambúrguer, queijo, maionese, tomate e alface',
    priceSmall: 20,
    priceLarge: 25,
    category: 'tradicional',
    preparationTime: '6-8 min',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400',
    ingredients: ['hambúrguer', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-maionese',
    name: 'X-Maionese',
    description: 'Hambúrguer, queijo, maionese',
    priceSmall: 19,
    priceLarge: 24,
    category: 'tradicional',
    preparationTime: '5-7 min',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=400',
    ingredients: ['hambúrguer', 'queijo', 'maionese']
  },
  {
    id: 'x-burguer',
    name: 'X-Burger',
    description: 'Hambúrguer, queijo',
    priceSmall: 18,
    priceLarge: 23,
    category: 'tradicional',
    preparationTime: '5-7 min',
    image: 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=400',
    ingredients: ['hambúrguer', 'queijo']
  },
  {
    id: 'x-bacon',
    name: 'X-Bacon',
    description: 'Hambúrguer, queijo, bacon, maionese, tomate e alface',
    priceSmall: 25,
    priceLarge: 30,
    category: 'tradicional',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400',
    ingredients: ['hambúrguer', 'queijo', 'bacon', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-egg',
    name: 'X-Egg',
    description: 'Hambúrguer, queijo, ovo, maionese, tomate e alface',
    priceSmall: 24,
    priceLarge: 30,
    category: 'tradicional',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1551615593-ef5fe247e8f7?w=400',
    ingredients: ['hambúrguer', 'queijo', 'ovo', 'maionese', 'tomate', 'alface']
  },

  // Lanches com Frango
  {
    id: 'duplo-especial',
    name: 'Duplo Especial',
    description: 'Frango, hambúrguer, presunto, queijo, bacon, ovo, maionese, tomate e alface',
    price: 33,
    category: 'frango',
    preparationTime: '15-18 min',
    image: 'https://images.unsplash.com/photo-1513185158878-8d064c2de2a2?w=400',
    ingredients: ['frango', 'hambúrguer', 'presunto', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'ki-galo',
    name: 'Ki Galo',
    description: 'Frango, queijo, bacon, ovo, maionese, tomate e alface',
    price: 30,
    category: 'frango',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1607013251379-e6eecfffe234?w=400',
    ingredients: ['frango', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'ki-lanche',
    name: 'Ki Lanche',
    description: 'Frango, queijo, bacon, maionese, tomate e alface',
    price: 28,
    category: 'frango',
    preparationTime: '10-12 min',
    image: 'https://images.unsplash.com/photo-1606755962773-d324e2d53141?w=400',
    ingredients: ['frango', 'queijo', 'bacon', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'especial',
    name: 'Especial',
    description: 'Frango, queijo, maionese, tomate e alface',
    price: 28,
    category: 'frango',
    preparationTime: '10-12 min',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400',
    ingredients: ['frango', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'x-frango',
    name: 'X-Frango',
    description: 'Frango, queijo, maionese, tomate e alface',
    price: 25,
    category: 'frango',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1548221607-d644ae1fcd2e?w=400',
    ingredients: ['frango', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'frango-salada',
    name: 'Frango Salada',
    description: 'Frango grelhado, maionese, tomate e alface',
    price: 26,
    category: 'frango',
    preparationTime: '10-12 min',
    image: 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=400',
    ingredients: ['frango grelhado', 'maionese', 'tomate', 'alface']
  },

  // Lanches Gourmet
  {
    id: 'insano',
    name: 'Insano',
    description: 'Hambúrguer duplo, costela, bacon, ovo, maionese, tomate e cebola',
    price: 33,
    category: 'gourmet',
    preparationTime: '15-20 min',
    image: 'https://images.unsplash.com/photo-1606755456206-1f6fcfc08951?w=400',
    ingredients: ['hambúrguer duplo', 'costela', 'bacon', 'ovo', 'maionese', 'tomate', 'cebola']
  },
  {
    id: 'x-pig',
    name: 'X-Pig',
    description: 'Hambúrguer, queijo prato, bacon, ovo, maionese e tomate',
    price: 31,
    category: 'gourmet',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1585238342024-78d387f4a707?w=400',
    ingredients: ['hambúrguer', 'queijo prato', 'bacon', 'ovo', 'maionese', 'tomate']
  },
  {
    id: 'x-picanha',
    name: 'X-Picanha',
    description: 'Hambúrguer de picanha, bacon, cheddar, mussarela, tomate e cebola',
    price: 33,
    category: 'gourmet',
    preparationTime: '15-18 min',
    image: 'https://images.unsplash.com/photo-1586816001966-79b736744398?w=400',
    ingredients: ['hambúrguer de picanha', 'bacon', 'cheddar', 'mussarela', 'tomate', 'cebola']
  },

  // Lanches Saborosos
  {
    id: 'furioso',
    name: 'Furioso',
    description: 'Pão especial, contra-filé, queijo, bacon, ovo, maionese, alface e rúcula',
    price: 43,
    category: 'saborosos',
    preparationTime: '18-20 min',
    image: 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400',
    ingredients: ['pão especial', 'contra-filé', 'queijo', 'bacon', 'ovo', 'maionese', 'alface', 'rúcula']
  },
  {
    id: 'lombo-bom-bom',
    name: 'Lombo Bom Bom',
    description: 'Lombo, queijo, bacon, ovo, maionese, tomate e alface',
    price: 31,
    category: 'saborosos',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400',
    ingredients: ['lombo', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'bauru-lombo',
    name: 'Bauru Lombo',
    description: 'Queijo, presunto, tomate e alface',
    price: 31,
    category: 'saborosos',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1571091655789-405eb7a3a3a8?w=400',
    ingredients: ['queijo', 'presunto', 'tomate', 'alface']
  },
  {
    id: 'americano',
    name: 'Americano',
    description: 'Queijo, presunto, tomate e alface',
    price: 22,
    category: 'saborosos',
    preparationTime: '6-8 min',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400',
    ingredients: ['queijo', 'presunto', 'tomate', 'alface']
  },
  {
    id: 'vegetariano',
    name: 'Vegetariano',
    description: 'Hambúrguer vegetal, queijo, maionese, tomate e alface',
    price: 25,
    category: 'saborosos',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1512152272829-e3139592d56f?w=400',
    ingredients: ['hambúrguer vegetal', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'russo',
    name: 'Russo',
    description: 'Hambúrguer, ovo, bacon, queijo, maionese, tomate e alface',
    price: 21,
    category: 'saborosos',
    preparationTime: '8-10 min',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=400',
    ingredients: ['hambúrguer', 'ovo', 'bacon', 'queijo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'misto-quente',
    name: 'Misto Quente',
    description: 'Queijo, presunto, maionese',
    price: 21,
    category: 'saborosos',
    preparationTime: '5-7 min',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
    ingredients: ['queijo', 'presunto', 'maionese']
  },

  // Combos e Especiais
  {
    id: 'coringa',
    name: 'Coringa',
    description: '2x Bacon + 1x Salada + Guaraná 1L',
    price: 60,
    category: 'combos',
    preparationTime: '15-20 min',
    image: 'https://images.unsplash.com/photo-1571091655789-405eb7a3a3a8?w=400',
    ingredients: ['2x x-bacon', '1x x-salada', 'guaraná 1L']
  },
  {
    id: 'double',
    name: 'Double',
    description: '2x Tudo + Guaraná 1L',
    price: 50,
    category: 'combos',
    preparationTime: '18-25 min',
    image: 'https://images.unsplash.com/photo-1585238342024-78d387f4a707?w=400',
    ingredients: ['2x x-tudo', 'guaraná 1L']
  },
  {
    id: 'salada-cheddar',
    name: 'Salada Cheddar',
    description: 'X-Salada + Cheddar + Batata 250g',
    price: 30,
    category: 'combos',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1551782450-17144efb9c50?w=400',
    ingredients: ['x-salada', 'cheddar', 'batata frita 250g']
  },
  {
    id: 'bacon-cheddar',
    name: 'Bacon Cheddar',
    description: 'X-Bacon + Cheddar + Batata 250g',
    price: 35,
    category: 'combos',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400',
    ingredients: ['x-bacon', 'cheddar', 'batata frita 250g']
  },

  // Beirutes e Bauru
  {
    id: 'beirute-hamburguer',
    name: 'Beirute Hambúrguer',
    description: 'Hambúrguer artesanal, presunto, queijo, bacon, ovo, maionese, tomate e alface',
    price: 52,
    category: 'beirutes',
    preparationTime: '15-18 min',
    image: 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400',
    ingredients: ['hambúrguer artesanal', 'presunto', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'beirute-frango',
    name: 'Beirute Frango',
    description: 'Frango, presunto, queijo, bacon, ovo, maionese, tomate e alface',
    price: 52,
    category: 'beirutes',
    preparationTime: '15-18 min',
    image: 'https://images.unsplash.com/photo-1607013251379-e6eecfffe234?w=400',
    ingredients: ['frango', 'presunto', 'queijo', 'bacon', 'ovo', 'maionese', 'tomate', 'alface']
  },
  {
    id: 'bauru-contra-file',
    name: 'Bauru Contra Filé',
    description: 'Pão francês, contra-filé, queijo, tomate e cebola',
    price: 34,
    category: 'beirutes',
    preparationTime: '12-15 min',
    image: 'https://images.unsplash.com/photo-1586816001966-79b736744398?w=400',
    ingredients: ['pão francês', 'contra-filé', 'queijo', 'tomate', 'cebola']
  },
  {
    id: 'bauru-linguica',
    name: 'Bauru Linguiça',
    description: 'Pão francês, linguiça, molho da casa, queijo, tomate e maionese',
    price: 31.5,
    category: 'beirutes',
    preparationTime: '10-12 min',
    image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400',
    ingredients: ['pão francês', 'linguiça', 'molho da casa', 'queijo', 'tomate', 'maionese']
  },

  // Acompanhamentos
  {
    id: 'batata-frita',
    name: 'Batata Frita 250g',
    description: 'Deliciosa batata frita sequinha e dourada',
    price: 16,
    category: 'acompanhamentos',
    preparationTime: '5-8 min',
    image: 'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=400',
    ingredients: ['batata', 'sal']
  },
];
