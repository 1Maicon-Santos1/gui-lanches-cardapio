import { useState, useMemo } from 'react';
import { CartProvider } from '@/react-app/hooks/useCart';
import Header from '@/react-app/components/Header';
import CategoryFilter from '@/react-app/components/CategoryFilter';
import MenuItemCard from '@/react-app/components/MenuItemCard';
import Cart from '@/react-app/components/Cart';
import Footer from '@/react-app/components/Footer';
import { menuItems, categories } from '@/react-app/data/menu';

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const filteredItems = useMemo(() => {
    let filtered = menuItems;

    // Filter by category
    if (selectedCategory) {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term) ||
        item.ingredients.some(ingredient => 
          ingredient.toLowerCase().includes(term)
        )
      );
    }

    return filtered;
  }, [searchTerm, selectedCategory]);

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? `${category.emoji} ${category.name}` : categoryId;
  };

  const groupedItems = useMemo(() => {
    const groups: { [key: string]: typeof menuItems } = {};
    
    filteredItems.forEach(item => {
      if (!groups[item.category]) {
        groups[item.category] = [];
      }
      groups[item.category].push(item);
    });
    
    return groups;
  }, [filteredItems]);

  return (
    <CartProvider>
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-red-50">
        <Header 
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          onCartClick={() => setIsCartOpen(true)}
        />
        
        <CategoryFilter
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />

        <main className="max-w-6xl mx-auto px-4 py-8">
          {/* Promoções em destaque */}
          <div className="mb-8 bg-gradient-to-r from-red-500 to-yellow-500 rounded-2xl p-6 text-white shadow-xl">
            <h2 className="text-2xl font-bold mb-2">🔥 Promoções da Semana</h2>
            <p className="text-lg">Combos especiais com desconto! Confira nossa seção de combos.</p>
          </div>

          {/* Search Results Info */}
          {searchTerm && (
            <div className="mb-6">
              <p className="text-gray-600">
                Resultados para "{searchTerm}": {filteredItems.length} item(s) encontrado(s)
              </p>
            </div>
          )}

          {/* Menu Items */}
          {Object.keys(groupedItems).length === 0 ? (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                Nenhum item encontrado
              </h3>
              <p className="text-gray-500">
                Tente buscar por outro termo ou categoria.
              </p>
            </div>
          ) : (
            Object.entries(groupedItems).map(([categoryId, items]) => (
              <div key={categoryId} className="mb-12">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
                  {getCategoryName(categoryId)}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {items.map((item) => (
                    <MenuItemCard key={item.id} item={item} />
                  ))}
                </div>
              </div>
            ))
          )}
        </main>

        <Footer />
        
        <Cart 
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
        />
      </div>
    </CartProvider>
  );
}
