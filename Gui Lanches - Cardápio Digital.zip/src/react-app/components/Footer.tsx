import { Phone, MapPin, Clock } from 'lucide-react';

export default function Footer() {
  const handleWhatsAppClick = () => {
    const phoneNumber = "5519971718931";
    const message = encodeURIComponent("Olá! Gostaria de fazer um pedido no Gui Lanches.");
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <footer className="bg-gradient-to-r from-gray-800 to-gray-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Contact Info */}
          <div className="text-center md:text-left">
            <h3 className="text-xl font-bold mb-4 text-yellow-400">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-center md:justify-start gap-2">
                <Phone className="w-5 h-5 text-green-400" />
                <span>(19) 97171-8931</span>
              </div>
              <div className="flex items-start justify-center md:justify-start gap-2">
                <MapPin className="w-5 h-5 text-red-400 mt-1" />
                <div>
                  <p>R. Quinzinho Otávio, 70</p>
                  <p>Centro, Vargem Grande do Sul - SP</p>
                </div>
              </div>
            </div>
          </div>

          {/* Opening Hours */}
          <div className="text-center">
            <h3 className="text-xl font-bold mb-4 text-yellow-400">Horário</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-2">
                <Clock className="w-5 h-5 text-blue-400" />
                <span>Segunda a Sábado</span>
              </div>
              <p>18:00 - 23:30</p>
              <p className="text-sm text-gray-300">Domingo: Fechado</p>
            </div>
          </div>

          {/* About */}
          <div className="text-center md:text-right">
            <h3 className="text-xl font-bold mb-4 text-yellow-400">Gui Lanches</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Os melhores lanches artesanais da região! 
              Ingredientes frescos, sabor incomparável e 
              atendimento de qualidade há mais de 10 anos.
            </p>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center">
          <p className="text-gray-400 text-sm mb-4">
            © 2024 Gui Lanches. Todos os direitos reservados.
          </p>
          
          {/* WhatsApp Button */}
          <button
            onClick={handleWhatsAppClick}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-semibold transition-all duration-200 hover:scale-105 flex items-center gap-2 mx-auto"
          >
            📱 Fazer Pedido via WhatsApp
          </button>
        </div>
      </div>

      {/* Fixed WhatsApp Button */}
      <button
        onClick={handleWhatsAppClick}
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 z-40 animate-bounce"
      >
        📱
      </button>
    </footer>
  );
}
