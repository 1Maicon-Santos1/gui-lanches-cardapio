import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '@/react-app/hooks/useCart';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Cart({ isOpen, onClose }: CartProps) {
  const { items, removeItem, updateQuantity, getTotalPrice, clearCart } = useCart();

  const formatPrice = (price: number) => {
    return `R$ ${price.toFixed(2).replace('.', ',')}`;
  };

  const getItemPrice = (item: any, size?: string) => {
    if (item.priceSmall && item.priceLarge) {
      return size === 'large' ? item.priceLarge : item.priceSmall;
    }
    return item.price || 0;
  };

  const generateWhatsAppMessage = () => {
    let message = "🍔 *PEDIDO GUI LANCHES* 🍔\n\n";
    
    items.forEach((cartItem, index) => {
      const price = getItemPrice(cartItem.item, cartItem.size);
      const sizeText = cartItem.size && cartItem.size !== 'regular' 
        ? ` (${cartItem.size === 'small' ? 'Pequeno' : 'Grande'})`
        : '';
      
      message += `${index + 1}. ${cartItem.item.name}${sizeText}\n`;
      message += `   Qtd: ${cartItem.quantity}x | ${formatPrice(price)} cada\n`;
      message += `   Subtotal: ${formatPrice(price * cartItem.quantity)}\n\n`;
    });
    
    message += `💰 *TOTAL: ${formatPrice(getTotalPrice())}*\n\n`;
    message += "📍 *Endereço para entrega:*\n";
    message += "_Por favor, informe seu endereço completo_\n\n";
    message += "⏰ Tempo estimado: 30-45 minutos";
    
    return encodeURIComponent(message);
  };

  const handleWhatsAppOrder = () => {
    const message = generateWhatsAppMessage();
    const phoneNumber = "5519971718931"; // Removendo caracteres especiais do número
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="bg-gradient-to-r from-yellow-400 to-red-500 p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <ShoppingBag className="w-6 h-6" />
                Seu Pedido
              </h2>
              <button
                onClick={onClose}
                className="text-white hover:bg-white/20 p-2 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4">
            {items.length === 0 ? (
              <div className="text-center py-8">
                <ShoppingBag className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 text-lg">Seu carrinho está vazio</p>
                <p className="text-gray-400 text-sm">Adicione alguns lanches deliciosos!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((cartItem, index) => {
                  const price = getItemPrice(cartItem.item, cartItem.size);
                  const sizeText = cartItem.size && cartItem.size !== 'regular' 
                    ? ` (${cartItem.size === 'small' ? 'Pequeno' : 'Grande'})`
                    : '';

                  return (
                    <div key={`${cartItem.item.id}-${cartItem.size}-${index}`} className="bg-gray-50 rounded-lg p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-800">
                            {cartItem.item.name}{sizeText}
                          </h3>
                          <p className="text-sm text-gray-600">{formatPrice(price)} cada</p>
                        </div>
                        <button
                          onClick={() => removeItem(cartItem.item.id, cartItem.size)}
                          className="text-red-500 hover:bg-red-100 p-1 rounded"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity - 1, cartItem.size)}
                            className="bg-gray-200 hover:bg-gray-300 p-1 rounded"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center font-medium">{cartItem.quantity}</span>
                          <button
                            onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity + 1, cartItem.size)}
                            className="bg-gray-200 hover:bg-gray-300 p-1 rounded"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="font-semibold text-red-600">
                          {formatPrice(price * cartItem.quantity)}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          {items.length > 0 && (
            <div className="border-t bg-white p-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold">Total:</span>
                <span className="text-2xl font-bold text-red-600">
                  {formatPrice(getTotalPrice())}
                </span>
              </div>
              
              <div className="space-y-2">
                <button
                  onClick={handleWhatsAppOrder}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
                >
                  📱 Fazer Pedido via WhatsApp
                </button>
                
                <button
                  onClick={clearCart}
                  className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 rounded-lg font-medium transition-colors"
                >
                  Limpar Carrinho
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
