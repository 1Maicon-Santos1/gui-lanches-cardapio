import { Search, ShoppingCart } from 'lucide-react';
import { useCart } from '@/react-app/hooks/useCart';

interface HeaderProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
  onCartClick: () => void;
}

export default function Header({ searchTerm, onSearchChange, onCartClick }: HeaderProps) {
  const { getTotalItems } = useCart();
  const totalItems = getTotalItems();

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-yellow-400 via-red-500 to-yellow-400 shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4">
        {/* Logo */}
        <div className="flex items-center justify-center mb-4">
          <div className="bg-white rounded-full p-3 shadow-xl">
            <img 
              src="https://mocha-cdn.com/019a3ba8-c585-746f-a525-ecd27606700c/image.png_1248.png" 
              alt="Gui Lanches Logo"
              className="w-16 h-16 object-contain"
            />
          </div>
          <div className="ml-4">
            <h1 className="text-3xl font-bold text-white drop-shadow-lg">GUI LANCHES</h1>
            <p className="text-white/90 text-sm font-medium">Peça seu lanche no balcão!</p>
          </div>
        </div>

        {/* Search and Cart */}
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar lanches ou ingredientes..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-full border-0 shadow-lg focus:ring-4 focus:ring-white/30 focus:outline-none text-gray-700 font-medium"
            />
          </div>
          
          <button
            onClick={onCartClick}
            className="relative bg-white text-red-600 p-3 rounded-full shadow-lg hover:bg-gray-50 transition-all duration-200 hover:scale-105"
          >
            <ShoppingCart className="w-6 h-6" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center animate-pulse">
                {totalItems}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
