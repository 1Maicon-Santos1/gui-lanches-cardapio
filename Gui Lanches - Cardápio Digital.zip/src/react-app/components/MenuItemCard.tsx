import { Plus, Clock } from 'lucide-react';
import { MenuItem } from '@/shared/types';
import { useCart } from '@/react-app/hooks/useCart';

interface MenuItemCardProps {
  item: MenuItem;
}

export default function MenuItemCard({ item }: MenuItemCardProps) {
  const { addItem } = useCart();

  const hasMultipleSizes = item.priceSmall && item.priceLarge;

  const handleAddToCart = (size?: 'small' | 'large') => {
    addItem(item, size || 'regular');
  };

  const formatPrice = (price: number) => {
    return `R$ ${price.toFixed(2).replace('.', ',')}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group hover:scale-[1.02]">
      <div className="relative">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 bg-yellow-400 text-black px-2 py-1 rounded-full text-xs font-bold shadow-md">
          <Clock className="w-3 h-3 inline mr-1" />
          {item.preparationTime}
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{item.name}</h3>
        <p className="text-gray-600 text-sm mb-3 leading-relaxed">{item.description}</p>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {item.ingredients.slice(0, 4).map((ingredient, index) => (
            <span
              key={index}
              className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full"
            >
              {ingredient}
            </span>
          ))}
          {item.ingredients.length > 4 && (
            <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
              +{item.ingredients.length - 4} mais
            </span>
          )}
        </div>

        {hasMultipleSizes ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-gray-600">Pequeno</span>
                <p className="text-lg font-bold text-red-600">{formatPrice(item.priceSmall!)}</p>
              </div>
              <button
                onClick={() => handleAddToCart('small')}
                className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full transition-colors duration-200 hover:scale-110"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-gray-600">Grande</span>
                <p className="text-lg font-bold text-red-600">{formatPrice(item.priceLarge!)}</p>
              </div>
              <button
                onClick={() => handleAddToCart('large')}
                className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full transition-colors duration-200 hover:scale-110"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <p className="text-2xl font-bold text-red-600">{formatPrice(item.price!)}</p>
            <button
              onClick={() => handleAddToCart()}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full font-medium transition-all duration-200 hover:scale-105 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Adicionar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
