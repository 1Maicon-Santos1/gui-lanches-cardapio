import z from "zod";

export const MenuItemSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  priceSmall: z.number().optional(),
  priceLarge: z.number().optional(),
  price: z.number().optional(),
  category: z.string(),
  preparationTime: z.string(),
  image: z.string().optional(),
  ingredients: z.array(z.string()),
});

export const CartItemSchema = z.object({
  item: MenuItemSchema,
  quantity: z.number(),
  size: z.enum(['small', 'large', 'regular']).optional(),
});

export const CategorySchema = z.object({
  id: z.string(),
  name: z.string(),
  emoji: z.string(),
  color: z.string(),
});

export type MenuItem = z.infer<typeof MenuItemSchema>;
export type CartItem = z.infer<typeof CartItemSchema>;
export type Category = z.infer<typeof CategorySchema>;
